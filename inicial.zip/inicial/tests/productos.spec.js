const request = require("supertest");
const server = require("../index");

describe("Operaciones CRUD", () => {

    // Verifica que la ruta GET /productos devuelva un ARREGLO y no este vacío


    // Verifica que devuelva error al consultar GET "/productos/:id" por un producto con id que no existe


    // Verifica que la ruta POST /productos está agregando un nuevo producto


    // Verifica si ingresas cualquier ruta diferente a las establecidas recibas un status code 404


    // Verifica que al actualizar un producto con id inexistente devuelve error 404


    // Verifica que al eliminar un producto, si envias un id inexistente devuelve error 404


});
